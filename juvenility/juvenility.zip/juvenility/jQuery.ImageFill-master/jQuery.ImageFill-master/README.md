jQuery.ImageFill
================

jQuery.imagefill stretches images so as to fill their containers.

Documentation and demos: <http://pioul.fr/jquery-imagefill>